$(function (){
  portfolio__content
  var mixer = mixitup('.portfolio__content');
});